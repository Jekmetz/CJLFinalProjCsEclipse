import java.util.Date;

/**
 * Timer used by the program to track the time required for execution
 * @author Curtis Ward, Jay Kmetz, Matthew Lazo
 *
 */
public class Timer {
  public static long startTime;

  public static void start(){
    startTime = System.currentTimeMillis();
  }

  public static Long stop(){
    long time = System.currentTimeMillis() - startTime;

    startTime = 0;
    return time;
  }
}
