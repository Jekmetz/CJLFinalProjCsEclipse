import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

/**
 * Load images and find average RGB values for a group of pixels within the image
 * @author Curtis Ward, Jay Kmetz, Matthew Lazo
 *
 */
class Emoji{
  private BufferedImage baseImage;
  public int size = 0;
  public Color[][] image = new Color[0][0];
  public Color avgColor;

  /**
   * Load an image into the program from the given filepath
   * @param filepath String
   */
  Emoji( String filepath ){
    this.baseImage = ImageUtils.loadBufferedImage(filepath);
    this.avgColor = LookupTable.getBufferedAverageColor(this.baseImage);
  }

  /**
   * Load the image and find the average RGB value for a group of pixels within the image
   * @param baseImage
   */
  Emoji( BufferedImage baseImage ){
    this.baseImage = baseImage;
    this.avgColor = LookupTable.getBufferedAverageColor(this.baseImage);
  }

  /**
   * Set the size of the image to be displayed
   * @param size int
   */
  public void setSize( int size ){
    BufferedImage buffImage;
    Color[][] resizedImage;

    if (size != this.size){
      this.size = size;

      //A dirty HACK
      buffImage = ImageUtils.convertToBufferedFromImage(
        this.baseImage.getScaledInstance( this.size, this.size, Image.SCALE_SMOOTH )
      );
      this.image = ImageUtils.convertTo2DFromBuffered( buffImage );
    }
  }
}
