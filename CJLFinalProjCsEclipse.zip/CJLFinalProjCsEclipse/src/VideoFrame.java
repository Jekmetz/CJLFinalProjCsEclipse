import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * Create the window in which the images are displayed
 * @author Curtis Ward, Jay Kmetz, Matthew Lazo
 *
 */
public class VideoFrame {
	//Declare all of the stuff that the class needs
	private JFrame frame;
	private JLabel label;
	private Timer timer = new Timer();

	/**
	 * Constructor for VideoFrme objects; create a new JFrame object
	 * @param name
	 */
	public VideoFrame(String name) {
		frame = new JFrame( name );
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		label = new JLabel();
		frame.setContentPane( label );
	}

	/**
	 * Display the window
	 */
	public void display() {
		frame.pack();
		frame.setMinimumSize( frame.getPreferredSize() );
		frame.setVisible( true );
	}

	/**
	 * Update the image according to @Timer
	 * @param imgs
	 * @param framerate
	 */
	public void repeatedImages( Images imgs , long framerate ) {
		TimerTask task = new TimerTask() {	//This is the object that the Timer depends on.
			int index = 0;			//Specifier for the frame to display
			public void run() {		//The method that defines what the timer will do
				index++;
				ImageIcon icon = new ImageIcon( imgs.getImage( index%imgs.getLength() ));	//Make the icon the next frame from 0-however many frames there are
				label = new JLabel(icon);
				frame.setContentPane(label);
				frame.pack();
			}
		};
		
		timer.schedule(task,0,1000/framerate);
	}

}

