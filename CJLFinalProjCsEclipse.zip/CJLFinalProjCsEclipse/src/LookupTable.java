import java.awt.Color;
import java.awt.image.BufferedImage;

/**
 * Handle the calculations of average RGB values for a "tile" and the distance between two Color objects
 * @author Curtis Ward, Jay Kmetz, Matthew Lazo
 *
 */
class LookupTable{

  public static Color standardColor = new Color( 255, 255, 255, 255 );

  /**
   * Find the average RGB values for a group of pixels in a bufferedImage
   * @param img
   * @return color Color
   */
  public static Color getBufferedAverageColor( BufferedImage img ){
    Color color= null;
    int width = img.getWidth();
    int height = img.getHeight();
    int total = 0;
    int r = 0;
    int g = 0;
    int b = 0;
    int a = 1;

    for ( int y = 0; y < height; y++ ) {
      for ( int x = 0; x < width; x++ ) {

        color = new Color(img.getRGB(x, y), true);

        if (color.getAlpha() > 0){
          total++;
          r = r + color.getRed();
          g = g + color.getGreen();
          b = b + color.getBlue();
          a = a + color.getAlpha();
        }else{
          r = r + 255;
          g = g + 255;
          b = b + 255;
          a = a + 255;
          total++;
        }

      }
    }

    r = r/total;
    g = g/total;
    b = b/total;
    a = a/total;

    return new Color( r, g, b, a );
  }

  /**
   * Find the distance between two Colors
   * @param color1
   * @param color2
   * @return double
   */
  public static double calculateColorDistance( Color color1, Color color2 ){

    return Math.sqrt(
      Math.pow( color1.getRed() - color2.getRed() , 2 ) +
      Math.pow( color1.getGreen() - color2.getGreen() , 2 ) +
      Math.pow( color1.getBlue() - color2.getBlue() , 2 ) +
      Math.pow( color1.getAlpha() - color2.getAlpha() , 2 )
    );
  }

  /**
   * Find the distance between two Colors using @calculateColorDistance
   * @param color
   * @return
   */
  public static double calculateStandardColorDistance( Color color ){
    return LookupTable.calculateColorDistance( LookupTable.standardColor, color );
  }
}
