import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * Handle the images and bufferedImages within the folder of images
 * @author Curtis Ward, Jay Kmetz, Matthew Lazo
 *
 */

public class Images {
	private BufferedImage[] img = null;
	
	private static Timer imageTimer = new Timer();

	/**
	 * Look through the folder of images and add each buffered imge into the folder
	 * @param filepath
	 */
	public void addImagesFromFolder( String filepath ) {
		File folder = null;
		File[] filenames = null;
		try {
			folder = new File( filepath ).getCanonicalFile();
			filenames = folder.listFiles();
		} catch (IOException e) {
			System.out.println( "Something went wrong" );	//Damn.
		}
		
		img = new BufferedImage[filenames.length];
		
		for (int i = 0; i < filenames.length; i++) {

			imageTimer.start();
			img[i] = loadImage( filenames[i].toString() );
			System.out.printf("Image %d of %d added in %d ms\n",i,filenames.length,imageTimer.stop());
			
		}
	}

	/**
	 * Load an image from the folder
	 * @param filepath
	 * @return buffImg BufferedImage
	 */
	private static BufferedImage loadImage( String filepath ){
		// Load in the image.
		BufferedImage buffImg = loadBufferedImage( filepath );
		return buffImg;
	}

	/**
	 * Load a bufferedImage from the folder
	 * @param filepath
	 * @return img BufferedImage
	 */
	private static BufferedImage loadBufferedImage( String filepath ) {
		// A BufferedImage initialization.
		BufferedImage img = null;

		// Try to read an image from the specified path.
		try {
			// Read the (image) File the path directs to.
			img = ImageIO.read( new File( filepath ) );
		} catch (IOException e) {
			System.out.println( "Could not load the image, please ensure the filepath" + " was properly specified." );
			e.printStackTrace();
			System.exit(1);
		}

		return img;
	}
	
	/**
	 * Get the image at the given index
	 * @param index
	 * @return img BufferedImage
	 */
	public BufferedImage getImage( int index ) {
		return img[index];		
	}
	
	/**
	 * Get the length of this bufferedImage
	 * @return int
	 */
	public int getLength() {
		return img.length;
	}

}

